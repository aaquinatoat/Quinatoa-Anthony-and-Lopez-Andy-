
public class Notes {

    public static void main(String[] args) {

        Student[] estudiantes = {
                new Student("Ana", 18.5),
                new Student("Pedro", 16.0),
                new Student("Maria", 19.20),
                new Student("Luis", 15.70),
                new Student("Sofia", 15.70)
        };

        int iteraciones = 0;
        int intercambios = 0;


        for (int i = 0; i < estudiantes.length - 1; i++) {

            for (int j = 0; j < estudiantes.length - 1 - i; j++) {

                iteraciones++;

                if (estudiantes[j].nota < estudiantes[j + 1].nota) {

                    Student temp = estudiantes[j];
                    estudiantes[j] = estudiantes[j + 1];
                    estudiantes[j + 1] = temp;

                    intercambios++;
                }
            }
        }


        System.out.println("TOP 3 Students");

        for (int i = 0; i < 3 && i < estudiantes.length; i++) {

            System.out.println(
                    (i + 1) + ". " + estudiantes[i].nombre
                            + " - Nota: " + estudiantes[i].nota
            );
        }


        System.out.println("\nTOTAL DE ITERACIONES: " + iteraciones);
        System.out.println("TOTAL DE INTERCAMBIOS: " + intercambios);
    }
}
