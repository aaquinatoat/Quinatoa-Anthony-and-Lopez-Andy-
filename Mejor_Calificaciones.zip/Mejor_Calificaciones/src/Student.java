
public class Student {

    String nombre;
    double nota;

    public Student(String nombre, double nota) {
        this.nombre = nombre;
        this.nota = nota;
    }
}
